# Jared's Session To-Dos

A private Foundry VTT v14 module that adds a small draggable to-do widget for session prep and live DM reminders.

## Features

- Floating draggable checklist widget.
- Toggle completed items.
- Open a larger editor from the widget or module settings.
- Add, edit, delete, and reorder items.
- Expand each item into detailed notes.
- Stores data in world settings, so each world has its own list.
- No D&D5e dependency; designed to be system-agnostic.

## Installation on The Forge

1. Upload/import the zipped module into The Forge as a private module.
2. Enable **Jared's Session To-Dos** in your world under **Manage Modules**.
3. Click the checklist button beside the scene controls, or open the editor from module settings.

## Usage

- Drag the small checklist widget by its title bar.
- Click a checkbox to mark an item complete.
- Click **Edit** to open the full editor.
- In the editor, click an item title to expand its details.
- Use ▲ and ▼ to reorder items.
- Use **Save** to persist changes.

## Notes

This module was written for Foundry VTT v14. It intentionally avoids system-specific APIs.
